#include <map>
#include <vector>

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 500
#endif

#include <ftw.h>
#include <limits.h> // PATH_MAX
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>

std::map<off_t, std::vector<std::string>> filesBySize;
std::vector<off_t> potentialDuplicates;

// compares files with filepaths file1 and file2 byte for byte
bool sameContents(std::string const &file1, std::string const &file2)
{
    size_t constexpr buffersize = 100;
    char buffer1[buffersize];
    char buffer2[buffersize];
    int fd1 = open(file1.data(), O_RDONLY);
    int fd2 = open(file2.data(), O_RDONLY);
    for (;;) {
        int rd1, rd2;
        rd1 = read(fd1, buffer1, buffersize);
        rd2 = read(fd2, buffer2, buffersize);
        if (rd1 == -1 || rd2 == -1) { // error while reading
            fprintf(stderr, "read failed\n");
            close(fd1);
            close(fd2);
            throw 1;
        }
        if (strncmp(buffer1, buffer2, buffersize) != 0)
            return false;
        if (rd1 == 0 || rd2 == 0) // EOF
            break;
    }
    return true;

}

// called for each file in the tree
int visitDir(const char *pathname, const struct stat *statbuf,
        int typeflag, struct FTW *ftwbuf)
{           // we are only concerned with regular files
    if (not S_ISREG(statbuf->st_mode)) 
        return 0;
    if (filesBySize.count(statbuf->st_size) > 0)
        potentialDuplicates.push_back(statbuf->st_size);

    filesBySize[statbuf->st_size].push_back(pathname);
    return 0;
}

// takes a vector of filenames with equal size and prints duplicates
void printDuplicates(std::vector<std::string> const &filenames)
{
    for (size_t idx = 0; idx != filenames.size(); ++idx) {
        for (size_t jdx = idx + 1; jdx < filenames.size(); ++jdx) {
            if (sameContents(filenames.at(idx), filenames.at(jdx))) {
                printf("%s and %s are the same file\n",
                        filenames.at(idx).data(), filenames.at(jdx).data());
            }
        }
    }
}

std::string getWorkingDirectory()
{
    char *currdir = new char[PATH_MAX];
    if (getcwd(currdir, PATH_MAX) == NULL) {
        delete currdir;
        fprintf(stderr, "getcwd failed\n");
        throw 1;
    }
    return currdir;
}

int main()
try
{
    int constexpr maxFdNo = 50; // maximum file descriptors we allow nftw to open
    int constexpr flags = 0; // do not follow symbolic links
    // calls visitDir on each file from the current working directory
    nftw(getWorkingDirectory().data(), &visitDir, maxFdNo, flags);

    for (auto const &val: potentialDuplicates) {
        printDuplicates(filesBySize[val]);
    }
}
catch(int err)
{
    return err;
}
