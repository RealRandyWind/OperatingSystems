#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include "misc.h"

#define RING_LIMIT_K 50
#define RING_MSG_DD "pid=%d: %d\n"

void cpipe(int N, int *cpid, const int fd0[2], int fdk[2], int fdn[2])
{	
	int n;
	fdn[0] = fd0[]
	for (n = 1; n < N; ++n)
	{
		*cpid = fork();
		if(*cpid)
		{
			if(pipe(fdn) < 0) { exit(EXIT_FAILURE); }
			return;
		}
	}
}

int main(int argc, char **argv)
{
	int cpid, pid, fd0[2], fdk[2], fdn[2], N, K, sz;

	if(argc != 2) { exit(EXIT_FAILURE); }

	N = atoi(argv[1]); K = 0; sz = sizeof(int);
	if(N < 2 || N > 16) { exit(EXIT_FAILURE); }

	if(pipe(fd0) < 0) { exit(EXIT_FAILURE); }
	write(fd0[1], &K, sz);
	cpipe(N, &cpid, fd0, fdk, fdn);
	
	pid = getpid();
	while(true)
	{
		if(cpid)
		{
			/* parent code */
			read(fdk[0], &K, sz);
			++K;
			write(fdk[1], &K, sz); 
		}
		else
		{
			/* child code */
			read(fdn[0], &K, sz);
			++K;
			write(fdn[1], &K, sz);
		}

		if(K > RING_LIMIT_K) { break; };
		
		printf(RING_MSG_DD, pid, K);
	}
	
	wait(nullptr);

	return EXIT_SUCCESS;
}
/* r w */
/* [{11, 4}, {3, 6}, {5, 8}, {7, 10}, {10, 4}] */
/* [{3, 4}, {5, 6}, {7, 8}, {9, 10}, {11, 12}] */