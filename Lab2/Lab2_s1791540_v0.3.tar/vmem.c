#include "misc.h"

int main()
{
	
}